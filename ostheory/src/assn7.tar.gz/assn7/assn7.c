
/* Promise of Originality
I promise that this source code file has, in it's entirety, been
written by myself and by no other person or persons. If at any time an
exact copy of this source code is found to be used by another person in
this term, I understand that both myself and the student that submitted
the copy will receive a zero on this assignment.
*/
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<math.h>
#include<stdbool.h>

#define MAX_READS (50)
#define BIG_NUMBER (900)

void swap(int* array, int i, int j);

int main(int argc, char** argv)
{
	printf("Assignment 7: Block Access Algorithm\n");
	printf("By: Cody Titmus\n");
	int* locations = malloc(MAX_READS * sizeof(int));
	int loc;
	int locGiven = 0;
	while(fscanf(stdin, "%d", &loc) == 1)
	{
	//	printf("%d\n", loc);
		*(locations + locGiven) = loc;
		++locGiven;
	}
	printf("FCFS Total Seek: %d\n", firstComeFirstServed(locations, locGiven));
	printf("SSTF Total Seek: %d\n", shortestSeekTimeFirst(locations, locGiven));
	printf("LOOK Total Seek: %d\n", look(locations, locGiven));
	printf("C-LOOK Total Seek: %d\n", p_look(locations, locGiven));
	free(locations);
	return 0;
}

int shortestSeekTimeFirst(int* seekLocations, int size)
{
	int* toFree = malloc(size * sizeof(int));
	memcpy(toFree,seekLocations, size * sizeof(int));
	int* nums = toFree;
	int position = *nums;
	nums++;
	int reads = 1;
	int seekTime = 0;
	while(reads != size)
	{
		int closest = BIG_NUMBER;
		int closestIndex;
		int i;
		for(i = 0; i < size-reads; ++i)
		{
			if(abs(position - nums[i]) < closest)
			{
				closest = abs(position - nums[i]);
				closestIndex = i;
			}
		}
		swap(nums, 0, closestIndex);
		seekTime += abs(position - *nums);
		position = *nums;
		nums++;
		++reads;
	}
	free(toFree);
	return seekTime;
}
int firstComeFirstServed(int* nums, int size)
{
	int position = (*nums);
	nums++;
	int reads = 1;
	int seekTime = 0;
	while(reads != size)
	{
		seekTime += abs(position - *nums);
		position = *nums;
		nums++;
		++reads;
	}
	return seekTime;
}

int look(int* seekLocations, int size)
{
	int* toFree = malloc(size * sizeof(int));
	memcpy(toFree,seekLocations, size * sizeof(int));
	int* nums = toFree;
	int position = *nums;
	nums++;
	int reads = 1;
	int seekTime = 0;
	bool toRight = true;
	while(reads != size)
	{
		int closest = BIG_NUMBER;
		int closestIndex;
		int i;
		for(i = 0; i < size-reads; ++i)
		{
			if(toRight)
			{
				if(abs(position - nums[i]) < closest && nums[i] > position)
				{
					closest = abs(position - nums[i]);
					closestIndex = i;
				}
			}
			else if(!toRight)
			{
				if(abs(position - nums[i]) < closest && nums[i] < position)
				{
					closest = abs(position - nums[i]);
					closestIndex = i;
				}

			}
		}
		if(closest == BIG_NUMBER)
		{
			toRight = !toRight;
			continue;
		}
		swap(nums, 0, closestIndex);
		seekTime += abs(position - *nums);
		position = *nums;
		nums++;
		++reads;
	}
	free(toFree);
	return seekTime;
}
int p_look(int* seekLocations, int size)
{
	int* toFree = malloc(size * sizeof(int));
	memcpy(toFree,seekLocations, size * sizeof(int));
	int* nums = toFree;
	int position = *nums;
	nums++;
	int reads = 1;
	int seekTime = 0;
	while(reads != size)
	{
		int closest = BIG_NUMBER;
		int closestIndex;
		int i;
		for(i = 0; i < size-reads; ++i)
		{
				if(abs(position - nums[i]) < closest && nums[i] > position)
				{
					closest = abs(position - nums[i]);
					closestIndex = i;
					//printf("found toright candidate %d with value %d\n", i, nums[i]);
				}
		}
		//printf("switching\n");
		if(closest == BIG_NUMBER)
		{
			//printf("switch should occur\n");
			for(i = 0; i < size-reads; ++i)
			{
				if(nums[i] < closest)
				{
					closest = nums[i];
					closestIndex = i;
				}
			}
			
		}
		swap(nums, 0, closestIndex);
		//printf("adding seektime %d\n", abs(position - *nums));
		seekTime += abs(position - *nums);
		position = *nums;
		nums++;
		++reads;
	}
	free(toFree);
	return seekTime;
}


void swap(int* array, int i, int j)
{
	int temp = *(array + i);
	*(array + i) = *(array + j);
	*(array + j) = temp;
}
