
/* Promise of Originality
I promise that this source code file has, in it's entirety, been
written by myself and by no other person or persons. If at any time an
exact copy of this source code is found to be used by another person in
this term, I understand that both myself and the student that submitted
the copy will receive a zero on this assignment.
*/
#include<stdio.h>
#include<stdlib.h>
#include<vector>
#include<iostream>
#include<algorithm>

#define MAX_JOBS (100)
class Process{
public:
int time;
int id;
bool started;
Process(int t, int id): id(id), time(t)
{
	started = false;
}
};

using namespace std;
//void first_come_first_serve(int*,int*);
void first_come_first_serve(vector<Process> prc, vector<int> subTime);
void shortest_job_first(vector<Process> prc, vector<int> subTime);
void shortest_remaining_time(vector<Process> prc, vector<int> subTime);
void round_robin(vector<Process> prc, vector<int> subTime,int);
int main(int argc, char** argv)
{
	int dur, subTime, pid;
	pid = 0;
	vector<int> stimes;
	vector<Process> dtimes;
	while(fscanf(stdin, "%d %d", &subTime, &dur) == 2)
	{
		stimes.push_back(subTime);
		dtimes.push_back(Process(dur, pid++));
		
	}
	printf("First Come, First Served\n");
	first_come_first_serve(dtimes, stimes);
	printf("Shortest Job First\n");
	shortest_job_first(dtimes, stimes);
	printf("Shortest Remaining Time First\n");
	shortest_remaining_time(dtimes, stimes);
	printf("Round Robin\n");
	round_robin(dtimes, stimes, 100);
}

double get_avg(vector<double> nums)
{
	double sum = 0;
	for(int i = 0; i < nums.size(); ++i)
	{
	sum += nums.at(i);
	}
	return sum / nums.size();
}
void first_come_first_serve(vector<Process> prc, vector<int> subTime)
{
	vector<Process> cpy = prc;
	int clock = subTime[prc[0].id];
	int* sTime = (int*)malloc(sizeof(int)*prc.size());
	int* eTime = (int*)malloc(sizeof(int)*prc.size());
	vector<Process> queue;
	queue.push_back(Process(0, 0));
	while(queue.size() > 0 || prc.size() > 0)
	{
		//if queue is empty advance clock
		if(queue.empty() && clock < subTime[prc[0].id])clock = subTime[prc[0].id];
		//add to queue
		while(prc.size() > 0 && subTime[prc[0].id] <= clock)
		{
			queue.push_back(prc[0]);
			prc.erase(prc.begin());
		}
		//remove prior from queue
		Process curr = queue[0];
		queue.erase(queue.begin());
		
		*(sTime + curr.id) = clock;
		//run/advance clock
		clock += curr.time;
		//enter ending time
		eTime[curr.id] = clock;
		
	}
	vector<double> resp, turn, wait;
	for(int i = 0; i < subTime.size(); ++i)
	{
	//cout << cpy[i].id << ':' << sTime[i] - subTime[i] << ':' << eTime[i] - subTime[i] - cpy[i].time  << ':' << eTime[i] - subTime[i]  <<  endl;
	resp.push_back(sTime[i] - subTime[i]);
	turn.push_back(eTime[i] - subTime[i]);
	wait.push_back(eTime[i] - subTime[i] - cpy[i].time);
	}
	printf("Avg. Resp.:%.2f, Avg. T.A.:%.2f, Avg. Wait:%.2f\n", get_avg(resp), get_avg(turn), get_avg(wait));
}

void shortest_job_first(vector<Process> prc, vector<int> subTime)
{
	vector<Process> cpy = prc;
	int clock = subTime[prc[0].id];
	int* sTime = (int*)malloc(sizeof(int)*prc.size());
	int* eTime = (int*)malloc(sizeof(int)*prc.size());
	vector<Process> queue;
	queue.push_back(Process(0, 0));
	while(queue.size() > 0 || prc.size() > 0)
	{
		//if queue is empty advance clock
		if(queue.empty() && clock < subTime[prc[0].id])clock = subTime[prc[0].id];
		//add to queue
		while(prc.size() > 0 && subTime[prc[0].id] <= clock)
		{
			queue.push_back(prc[0]);
			prc.erase(prc.begin());
		}
		//remove prior from queue
		int smallest = 500, index;
		for(int i = 0; i < queue.size(); ++i)
		{
			if(queue[i].time < smallest)
			{
				smallest = queue[i].time;
				index = i;
			}
		}
		swap(queue[0], queue[index]);
		Process curr = queue[0];
		queue.erase(queue.begin());
		
		*(sTime + curr.id) = clock;
		//run/advance clock
		clock += curr.time;
		//enter ending time
		eTime[curr.id] = clock;
		
	}
	vector<double> resp, turn, wait;
	for(int i = 0; i < subTime.size(); ++i)
	{
	//cout << cpy[i].id << ':' << sTime[i] - subTime[i] << ':' << eTime[i] - subTime[i] - cpy[i].time  << ':' << eTime[i] - subTime[i]  <<  endl;
	resp.push_back(sTime[i] - subTime[i]);
	turn.push_back(eTime[i] - subTime[i]);
	wait.push_back(eTime[i] - subTime[i] - cpy[i].time);
	}
	printf("Avg. Resp.:%.2f, Avg. T.A.:%.2f, Avg. Wait:%.2f\n", get_avg(resp), get_avg(turn), get_avg(wait));
}

void shortest_remaining_time(vector<Process> prc, vector<int> subTime)
{
	vector<Process> cpy = prc;
	int clock = subTime[prc[0].id];
	int* sTime = (int*)malloc(sizeof(int)*prc.size());
	int* eTime = (int*)malloc(sizeof(int)*prc.size());
	vector<Process> queue;
	queue.push_back(Process(0, 0));
	while(queue.size() > 0 || prc.size() > 0)
	{
		//if queue is empty advance clock
		if(queue.empty() && clock < subTime[prc[0].id])clock = subTime[prc[0].id];
		//add to queue
		while(prc.size() > 0 && subTime[prc[0].id] <= clock)
		{
			queue.push_back(prc[0]);
			prc.erase(prc.begin());
		}
		//remove prior from queue
		int smallest = 500, index;
		for(int i = 0; i < queue.size(); ++i)
		{
			if(queue[i].time < smallest)
			{
				smallest = queue[i].time;
				index = i;
			}
		}
		swap(queue[0], queue[index]);
		Process curr = queue[0];
		queue.erase(queue.begin());
		
		if(curr.started == false)
			*(sTime + curr.id) = clock;
		curr.started = true;
		int toRun;
		if(prc.size() > 0)
		toRun = min(curr.time, subTime[prc[0].id] - clock);
		else
			toRun = curr.time;
		//run/advance clock
		//clock += curr.time;
		clock += toRun;
		curr.time -= toRun;
		//enter ending time
		if(curr.time == 0)
			eTime[curr.id] = clock;
		else
			queue.push_back(curr);
	}
	vector<double> resp, turn, wait;
	for(int i = 0; i < subTime.size(); ++i)
	{
	//cout << cpy[i].id << ':' << sTime[i] - subTime[i] << ':' << eTime[i] - subTime[i] - cpy[i].time  << ':' << eTime[i] - subTime[i]  <<  endl;
	resp.push_back(sTime[i] - subTime[i]);
	turn.push_back(eTime[i] - subTime[i]);
	wait.push_back(eTime[i] - subTime[i] - cpy[i].time);
	}
	printf("Avg. Resp.:%.2f, Avg. T.A.:%.2f, Avg. Wait:%.2f\n", get_avg(resp), get_avg(turn), get_avg(wait));
}

void round_robin(vector<Process> prc, vector<int> subTime, int quantum)
{
	vector<Process> cpy = prc;
	int clock = subTime[prc[0].id];
	int* sTime = (int*)malloc(sizeof(int)*prc.size());
	int* eTime = (int*)malloc(sizeof(int)*prc.size());
	vector<Process> queue;
	queue.push_back(Process(0, 0));
	while(queue.size() > 0 || prc.size() > 0)
	{
		//if queue is empty advance clock
		if(queue.empty() && clock < subTime[prc[0].id])clock = subTime[prc[0].id];
		//add to queue
		while(prc.size() > 0 && subTime[prc[0].id] <= clock)
		{
			queue.push_back(prc[0]);
			prc.erase(prc.begin());
		}
		//remove prior from queue
		Process curr = queue[0];
		queue.erase(queue.begin());
		
		if(curr.started == false)
			*(sTime + curr.id) = clock;
		curr.started = true;
		int toRun;
		
		toRun = min(curr.time, quantum);
		
		//run/advance clock
		//clock += curr.time;
		clock += toRun;
		curr.time -= toRun;
		//enter ending time
		if(curr.time == 0)
			eTime[curr.id] = clock;
		else
		{
			while(prc.size() > 0 && subTime[prc[0].id] <= clock)
			{
				queue.push_back(prc[0]);
				prc.erase(prc.begin());
			}
			queue.push_back(curr);
		}
			
	}
	vector<double> resp, turn, wait;
	for(int i = 0; i < subTime.size(); ++i)
	{
	//cout << cpy[i].id << ':' << sTime[i] - subTime[i] << ':' << eTime[i] - subTime[i] - cpy[i].time  << ':' << eTime[i] - subTime[i]  <<  endl;
	resp.push_back(sTime[i] - subTime[i]);
	turn.push_back(eTime[i] - subTime[i]);
	wait.push_back(eTime[i] - subTime[i] - cpy[i].time);
	}
	printf("Avg. Resp.:%.2f, Avg. T.A.:%.2f, Avg. Wait:%.2f\n", get_avg(resp), get_avg(turn), get_avg(wait));
}
