
/* Promise of Originality
I promise that this source code file has, in it's entirety, been
written by myself and by no other person or persons. If at any time an
exact copy of this source code is found to be used by another person in
this term, I understand that both myself and the student that submitted
the copy will receive a zero on this assignment.
*/
#include<stdio.h>
#include<stdlib.h>
#include<pthread.h>

//finds the maximum number of factors an integer can have
int maxNumberOfPrimes(int);
//this function takes a char pointer and turns the value into an int
//it then allocates memory and calles primes() to create an array of the factors
void* changeToPrime(void*);
//first parameter is the int you want to so find the factors for and the second
//parameter is where the factors will be stored
//the first element will be the number of factors and the subsequent elements will be the factors
int* primes(int, int*);

int main(int argc, char** argv)
{

	pthread_t* threads = (pthread_t*)malloc(sizeof(pthread_t)*argc-1);
	int** ret = malloc(sizeof(int*) * argc-1);
	
	int i;
	for(i = 0; i < argc-1; ++i)
	{
		pthread_create(&threads[i], NULL, changeToPrime, *(argv + i + 1));
	}
	for(i = 0; i < argc-1; ++i)
	{
		pthread_join(threads[i], (void**)&ret[i]);
		int* current = ret[i];
		printf("%s: ", argv[i+1]);
		int h;
		for(h = 0; h < current[0]; ++h)
		{
			printf("%d  ", current[h+1]);
		}
		printf("\n");
	}
	
	for(i = 0; i < argc-1; ++i)
	{
		free(ret[i]);
	}
	free(ret);
	free(threads);
	return 0;
}

void* changeToPrime(void* in)
{
	char* data = (char*)in;
	int num = atoi(data);
	int* test = (int*)malloc(sizeof(int) * maxNumberOfPrimes(num));
	*test = 0;
	primes(num, test);
	return test;
}

int* primes(int factor, int* store)
{		
	int guess = factor/2;
	while(guess > 1)
	{
		if(factor % guess == 0)
		{
			primes(factor / guess, store);
			primes(guess, store);
			return store;
		}
		--guess;
	}
	
	++*store;
	*(store + *(store)) = factor;
	return store;
}

int maxNumberOfPrimes(int num)
{
	int maxNumber = 1;
	int guess = 2;
	while(num >= guess)
	{
		guess *= 2;
		++maxNumber;
	}
	return maxNumber;
}
