/* Promise of Originality
I promise that this source code file has, in it's entirety, been
written by myself and by no other person or persons. If at any time an
exact copy of this source code is found to be used by another person in
this term, I understand that both myself and the student that submitted
the copy will receive a zero on this assignment.
*/
#include<stdio.h>
#include<unistd.h>

int main(int argc, char** argv)
{
	pid_t pid = fork();
	int status;
	if(pid > 0)
	{
		printf("PARENT started, now waiting for procedd ID#%d\n", pid);
		wait(pid, &status, 0);
		printf("PARENT resumed. Child exit code of %d. Now terminating parent\n", status);
	}
	else
	{
		printf("CHILD started. ");
		if(argc == 2)
		{
			printf("one argumnet provided. calling execlp()\n");
			execlp(*(argv+1), *(argv+1), NULL);
		}
		else if(argc > 2)
		{
			printf("more than one argument provided. calling execvp()\n");
			
			execvp(*(argv+1), argv+1);
		}
		else
		{
			printf("No arguments provided\n");
		}
		printf("terminating child\n");
	}
	return 0;
}
