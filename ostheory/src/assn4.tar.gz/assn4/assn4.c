
/* Promise of Originality
I promise that this source code file has, in it's entirety, been
written by myself and by no other person or persons. If at any time an
exact copy of this source code is found to be used by another person in
this term, I understand that both myself and the student that submitted
the copy will receive a zero on this assignment.
*/
#include<stdio.h>
#include<stdlib.h>
#include<semaphore.h>

#define BUFFER_SIZE (3)

struct number{
	int num;//number
	int size;//number of factors
	int* factors;// points to factors of the number
};
//finds the maximum number of factors an integer can have
int maxNumberOfPrimes(int);
//first parameter is the int you want to so find the factors for and the second
//parameter is struct where the factors will be stored
//the first element will be the number of factors and the subsequent elements will be the factors
void primes(int,struct number*); 

void* consumer(void*);
void* producer(void*);

sem_t lock, lock_full;
sem_t lockT, lockT_full;

int* mainBuffer;
struct number* threadBuffer;

int main(int argc, char** argv)
{
	sem_init(&lock_full, 0, BUFFER_SIZE);
	sem_init(&lock, 0, 0);
	sem_init(&lockT_full, 0, BUFFER_SIZE);
	sem_init(&lockT, 0, 0);
	mainBuffer = (int*)malloc(BUFFER_SIZE * sizeof(int));
	threadBuffer = malloc(BUFFER_SIZE*sizeof(struct number));
	pthread_t producert, consumert;
	pthread_create(&producert, NULL, producer, NULL);
	pthread_create(&consumert, NULL, consumer, NULL);
	
	int i;
	for(i=0; i < argc-1; ++i)
	{
		sem_wait(&lock_full);
		*(mainBuffer + i % BUFFER_SIZE) = atoi(argv[i+1]);
		sem_post(&lock);
	}
	//add a flag to tell threads to finish	
	sem_wait(&lock_full);
	mainBuffer[(argc-1)%BUFFER_SIZE] = -1;	
	sem_post(&lock);
	//let the threads finish and cleanup
	pthread_join(producert, NULL);
	pthread_join(consumert, NULL);
	free(mainBuffer);
	free(threadBuffer);
	return 0;
}


void primes(int factor, struct number* store)
{
	int guess = factor/2;
	while(guess > 1)
	{
		if(factor % guess == 0)
		{
			primes(factor / guess, store);
			primes(guess, store);
			return;
		}
		--guess;
	}
	store->factors[store->size] = factor;
	++store->size;
	return;
}

int maxNumberOfPrimes(int num)
{
	int maxNumber = 1;
	int guess = 2;
	while(num >= guess)
	{
		guess *= 2;
		++maxNumber;
	}
	return maxNumber;
}
void* producer(void* in)
{
	int i;
	for(i = 0; ; ++i)
	{
		sem_wait(&lock);
		struct number num;
		num.num = mainBuffer[i % BUFFER_SIZE];
		//exit if num has the exit value
		if(num.num == -1)
		{
			sem_wait(&lockT_full);
			threadBuffer[i % BUFFER_SIZE] = num;	
			sem_post(&lockT);
			break;
		}
		num.factors = (int*)malloc(maxNumberOfPrimes(num.num)*sizeof(int));
		num.size = 0;
		primes(num.num, &num);
		sem_wait(&lockT_full);
		threadBuffer[i % BUFFER_SIZE] = num;
		sem_post(&lockT);
		sem_post(&lock_full);
	}
}

void* consumer(void* in)
{
	int i;
	for(i = 0; ; ++i)
	{
		struct number num;
		sem_wait(&lockT);
		num = *(threadBuffer + i % BUFFER_SIZE);
		//exit thread if given the flag
		if(num.num == -1)break;
		printf("%d: ", num.num);
		int h;
		for(h=0; h<num.size;++h)
		{
			printf("%d ", num.factors[h]);
		}
		printf("\n");
		free(num.factors);
		sem_post(&lockT_full);
	}
}
