
#include<stdio.h>

int main(int argc, char** argv)
{

	unsigned long int num = strtol(argv[1], NULL, 16);
	printf("Logical Addr:0x%08lX", num);
	printf(" - Page Index:0x%08lX",num >> 12 );
	printf(" - Offset:0x%08lX\n", num % 4096);
	return 0;
}
